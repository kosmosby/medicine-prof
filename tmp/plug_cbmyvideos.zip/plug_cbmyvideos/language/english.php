<?php
/*************************************************************
* Joomla Community Builder Customize Plugin
* @package Community Builder
* @subpackage language/english.php
* @author Stiggi <stiggi@voodootools.de>
* @link http://voodootools.de
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
*************************************************************/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

define("MYVID_PREV", 'Prev');
define("MYVID_NEXT", 'Next');
define("MYVID_SHARE",'Share a new Video');
define("MYVID_SUBMIT", 'Submit');
define("MYVID_SET_BOX_TO_REMOVE", 'set this box active to remove the image');
define("MYVID_RESET_YOUR_SETTINGS",'Delete your custom css file - reset to defaults');
define("MYVID_CONFIORM_DELETE_STYLES",'Are you really sure to delete your style settings?');
define("MYVID_PLEASE_SELECT",'Please select...');
?>
